
public class User {
  String username;
    String password;
    String cellNumber;
    String firstName;
    String lastName;

    public User(String username, String password, String cellNumber, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.cellNumber = cellNumber;
        this.firstName = firstName;
        this.lastName = lastName;
    }
}    

